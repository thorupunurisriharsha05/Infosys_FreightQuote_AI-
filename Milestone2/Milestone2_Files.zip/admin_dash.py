"""admin_dash.py — FreightQuote AI Admin Dashboard (Milestone 2)
Adds: Add User form, Delete User, Unlock Account, ML Model Card tab.
"""
import subprocess, datetime
import streamlit as st
import pandas as pd
import plotly.express as px
from db import get_conn
from notifications import get_recent_alerts
from ui_theme import render_card, COLORS
from auth import hash_txt, password_strength

_APP_START = datetime.datetime.now()


def _smi(query):
    try:
        r = subprocess.run(
            ["nvidia-smi", f"--query-gpu={query}", "--format=csv,noheader,nounits"],
            capture_output=True, text=True, timeout=3)
        return r.stdout.strip()
    except Exception:
        return "N/A"


def render_admin_dashboard(project="freight"):
    render_card('<h3 style="margin:0;">🛡️ Admin Dashboard — System Intelligence</h3>')

    # ── 1. System Health ─────────────────────────────────────────────────────
    st.markdown(f'<h4 style="color:{COLORS["text_heading"]};margin:16px 0 8px;">⚙️ System Health</h4>',
                unsafe_allow_html=True)
    gpu_mem  = _smi("memory.used")
    gpu_tot  = _smi("memory.total")
    gpu_util = _smi("utilization.gpu")
    uptime   = str(datetime.datetime.now() - _APP_START).split(".")[0]
    h1, h2, h3, h4 = st.columns(4)
    for col, icon, label, val in [
        (h1, "🖥️", "GPU VRAM Used",  f"{gpu_mem} / {gpu_tot} MB"),
        (h2, "⚡", "GPU Utilization", f"{gpu_util}%"),
        (h3, "🕒", "App Uptime",      uptime),
        (h4, "✅", "LLM Status",      "Active" if gpu_mem != "N/A" else "Standby"),
    ]:
        col.markdown(
            f'<div class="pn-card" style="text-align:center;padding:14px;">'
            f'<div style="font-size:26px;">{icon}</div>'
            f'<h3 style="margin:6px 0 2px;font-size:1.1rem;">{val}</h3>'
            f'<p style="margin:0;color:{COLORS["text_muted"]};font-size:12px;">{label}</p>'
            f'</div>', unsafe_allow_html=True)

    st.markdown("---")

    user_tab, ml_tab, alert_tab = st.tabs(["👥 User Management", "📈 ML Model Card", "🔔 Alert Log"])

    # ── 2. User Management: Add / Delete / Unlock ────────────────────────────
    with user_tab:
        with st.expander("➕ Add New User", expanded=False):
            with st.form("add_user_form", clear_on_submit=True):
                au_user = st.text_input("Username")
                au_email = st.text_input("Email")
                au_pw = st.text_input("Initial Password", type="password")
                au_role = st.selectbox("Role", ["Admin", "Logistics Manager", "Pricing Analyst",
                                                "Carrier Auditor", "Executive"])
                submitted = st.form_submit_button("✨ Create Account")
                if submitted:
                    if not (au_user and au_email and au_pw):
                        st.warning("All fields are required.")
                    else:
                        _, _, allowed, msg = password_strength(au_pw)
                        if not allowed:
                            st.warning(msg)
                        else:
                            try:
                                with get_conn() as conn:
                                    conn.execute(
                                        "INSERT INTO users (username, email, password_hash, role, "
                                        "security_question, security_answer_hash) VALUES (?, ?, ?, ?, ?, ?)",
                                        (au_user, au_email, hash_txt(au_pw), au_role,
                                         "What is your pet name?", hash_txt("admin")))
                                    conn.commit()
                                st.success(f"✅ User '{au_user}' created with role [{au_role}].")
                                st.rerun()
                            except Exception:
                                st.error("Failed — username or email may already exist.")

        st.markdown(f'<h4 style="color:{COLORS["text_heading"]};margin:12px 0 8px;">👥 Registered Users</h4>',
                    unsafe_allow_html=True)
        with get_conn() as conn:
            try:
                users_df = pd.read_sql(
                    "SELECT id, username, role, email, account_status, failed_attempts, "
                    "created_at FROM users ORDER BY id DESC", conn)
            except Exception:
                users_df = pd.DataFrame(columns=["id","username","role","email",
                                                 "account_status","failed_attempts","created_at"])

        if users_df.empty:
            st.info("No users registered yet.")
        else:
            for _, row in users_df.iterrows():
                is_locked = (row.get("account_status") == "locked") or (row.get("failed_attempts", 0) or 0) >= 3
                uc1, uc2, uc3, uc4, uc5 = st.columns([2, 1.6, 2, 1, 1])
                uc1.markdown(f"**{row['username']}**  \n<span style='font-size:11px;color:{COLORS['text_muted']};'>{row['email']}</span>",
                             unsafe_allow_html=True)
                uc2.markdown(f'<span style="color:#0066cc;font-weight:600;">[{row["role"]}]</span>',
                             unsafe_allow_html=True)
                status_color = "#f87171" if is_locked else "#34d399"
                status_label = "🔒 Locked" if is_locked else "✅ Active"
                uc3.markdown(f'<span style="color:{status_color};font-weight:600;">{status_label}</span>',
                             unsafe_allow_html=True)
                with uc4:
                    if is_locked:
                        if st.button("🔓", key=f"unlock_{row['id']}", help=f"Unlock {row['username']}"):
                            with get_conn() as c:
                                c.execute("UPDATE users SET failed_attempts=0, lock_until=NULL, "
                                         "account_status='active' WHERE id=?", (row["id"],))
                                c.commit()
                            st.success(f"✅ User account unlocked successfully.")
                            st.rerun()
                with uc5:
                    if st.button("🗑️", key=f"del_user_{row['id']}", help=f"Delete {row['username']}"):
                        with get_conn() as c:
                            c.execute("DELETE FROM users WHERE id=?", (row["id"],))
                            c.commit()
                        st.success(f"Deleted {row['username']}")
                        st.rerun()

    # ── 3. ML Model Card ──────────────────────────────────────────────────────
    with ml_tab:
        st.markdown(f'<h4 style="color:{COLORS["text_heading"]};margin:0 0 8px;">📈 ML Model Card — All Agents</h4>',
                    unsafe_allow_html=True)
        with get_conn() as conn:
            try:
                ml_df = pd.read_sql(
                    "SELECT agent_name, model_name, r2_score, rmse, accuracy, "
                    "training_rows, created_at FROM ml_models ORDER BY id DESC", conn)
            except Exception:
                ml_df = pd.DataFrame()
        if ml_df.empty:
            st.info("No model training records found. Run retraining from Analytics tab.")
        else:
            st.dataframe(ml_df, use_container_width=True, hide_index=True)
            for agent in ml_df["agent_name"].unique():
                sub = ml_df[ml_df["agent_name"] == agent]
                best = sub.loc[sub["r2_score"].idxmax()] if sub["r2_score"].notna().any() else sub.iloc[0]
                metric_label = "R²" if "Pricing" in agent else "ROC-AUC"
                st.markdown(
                    f'<div class="pn-card" style="padding:12px 16px;">'
                    f'<b>{agent}</b> — Champion: <b>{best["model_name"]}</b> '
                    f'({metric_label} = {best["r2_score"]:.4f})</div>',
                    unsafe_allow_html=True)

    # ── 4. Live Alert Log ────────────────────────────────────────────────────
    with alert_tab:
        st.markdown(f'<h4 style="color:{COLORS["text_heading"]};margin:0 0 8px;">🔔 Live Alert Log</h4>',
                    unsafe_allow_html=True)
        filt = st.selectbox("Filter by type", ["All","In-App","Email","SMS"], key="admin_alert_filt")
        alerts = get_recent_alerts(50)
        for a in alerts:
            if filt != "All" and a[1].lower() != filt.lower():
                continue
            badge = {"email":"#ffd803","sms":"#f87171","in-app":"#34d399"}.get(a[1].lower(),"#bae8e8")
            st.markdown(
                f'<div style="border-left:4px solid {badge};padding:4px 10px;margin:3px 0;'
                f'font-size:13px;"><b>[{a[1].upper()}]</b> {a[3]} '
                f'<span style="color:{COLORS["text_muted"]};float:right;">{a[4]}</span></div>',
                unsafe_allow_html=True)
