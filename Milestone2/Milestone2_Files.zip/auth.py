"""
FreightQuote AI - auth.py (Milestone 2)
Adds on top of Milestone 1:
  - Progressive account lockout (3rd/4th/5th failed login attempts)
  - Dynamic password strength checker (Weak / Average / Good)
  - Forgot Password via Gmail OTP with resend cooldown (60s / 180s / 300s / 1hr)
  - Security-question route retained as a second recovery path
"""
import sqlite3, jwt, bcrypt, datetime, time, secrets, smtplib, streamlit as st
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.utils import formatdate, make_msgid

from config import DB_PATH, JWT_SECRET_KEY, ADMIN_EMAIL, ADMIN_PASSWORD, EMAIL_ID, EMAIL_PASSWORD
from ui_theme import COLORS

JWT_SECRET = JWT_SECRET_KEY

def get_conn():
    return sqlite3.connect(DB_PATH, check_same_thread=False)

def hash_txt(t):
    return bcrypt.hashpw(t.encode(), bcrypt.gensalt()).decode()

def check_txt(t, h):
    try: return bcrypt.checkpw(t.encode(), h.encode()) if h else False
    except Exception: return False

def make_jwt(email, username, role="User"):
    return jwt.encode({"email": email, "username": username, "role": role,
                       "exp": datetime.datetime.utcnow() + datetime.timedelta(hours=6)},
                      JWT_SECRET, algorithm="HS256")

def verify_jwt(token):
    try: return jwt.decode(token, JWT_SECRET, algorithms=["HS256"])
    except Exception: return None

@st.cache_resource
def init_auth():
    with get_conn() as conn:
        conn.execute("""CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE, email TEXT UNIQUE, password_hash TEXT,
            security_question TEXT, security_answer_hash TEXT,
            role TEXT DEFAULT 'User',
            failed_attempts INTEGER DEFAULT 0,
            lock_until TIMESTAMP DEFAULT NULL,
            account_status TEXT DEFAULT 'active',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)""")
        for col_def in ["security_question TEXT", "security_answer_hash TEXT",
                        "failed_attempts INTEGER DEFAULT 0",
                        "lock_until TIMESTAMP DEFAULT NULL",
                        "account_status TEXT DEFAULT 'active'"]:
            try: conn.execute(f"ALTER TABLE users ADD COLUMN {col_def}")
            except Exception: pass
        conn.execute("""CREATE TABLE IF NOT EXISTS otp_resend_tracker (
            email TEXT PRIMARY KEY, otp_resend_count INTEGER DEFAULT 0,
            otp_next_allowed REAL DEFAULT 0)""")
        if not conn.execute("SELECT id FROM users WHERE email=?", (ADMIN_EMAIL,)).fetchone():
            conn.execute("""INSERT OR IGNORE INTO users
                         (username, email, password_hash, security_question, security_answer_hash, role)
                         VALUES (?, ?, ?, ?, ?, ?)""",
                         ("Administrator", ADMIN_EMAIL, hash_txt(ADMIN_PASSWORD),
                          "What is your pet name?", hash_txt("admin"), "Admin"))
        conn.commit()

# ── Password strength policy (Section 6) ────────────────────────────────────
def password_strength(pw):
    """Returns (badge, label, allowed:bool, message)"""
    n = len(pw or "")
    if n < 5:
        return ("🔴", "Weak", False,
                "Password too weak (minimum 5 characters required).")
    elif n < 10:
        return ("🟡", "Average", True,
                "🟡 Average strength (10+ characters recommended for enterprise security).")
    else:
        return ("🟢", "Good", True,
                "🟢 Good password strength — proceed with bcrypt hashing.")

def render_password_strength_live(pw):
    if not pw:
        return
    badge, label, _, msg = password_strength(pw)
    st.caption(f"{badge} **{label}** — {msg}")

# ── Progressive lockout (Section 5) ─────────────────────────────────────────
def _now():
    return datetime.datetime.utcnow()

def _parse_ts(ts):
    if not ts: return None
    try: return datetime.datetime.fromisoformat(ts)
    except Exception: return None

def register_failed_attempt(email):
    with get_conn() as conn:
        row = conn.execute("SELECT failed_attempts FROM users WHERE email=?", (email,)).fetchone()
        if not row: return None
        attempts = (row[0] or 0) + 1
        lock_until, status, msg = None, "active", None
        if attempts == 3:
            lock_until = (_now() + datetime.timedelta(seconds=300)).isoformat()
            msg = "⏳ Account temporarily locked for 5 minutes due to 3 failed attempts."
        elif attempts == 4:
            lock_until = (_now() + datetime.timedelta(seconds=900)).isoformat()
            msg = "⏳ Account temporarily locked for 15 minutes due to 4 failed attempts."
        elif attempts >= 5:
            status = "locked"
            msg = ("❌ Account permanently locked due to 5 failed attempts. "
                   "Only the System Administrator can unlock this account via the Admin Dashboard.")
        conn.execute("UPDATE users SET failed_attempts=?, lock_until=?, account_status=? WHERE email=?",
                     (attempts, lock_until, status, email))
        conn.commit()
        return msg

def reset_failed_attempts(email):
    with get_conn() as conn:
        conn.execute("UPDATE users SET failed_attempts=0, lock_until=NULL WHERE email=?", (email,))
        conn.commit()

def check_lock_status(email):
    """Returns (is_locked: bool, message: str|None). Auto-clears an expired temporary lock."""
    with get_conn() as conn:
        row = conn.execute("SELECT lock_until, account_status FROM users WHERE email=?", (email,)).fetchone()
    if not row:
        return False, None
    lock_until_raw, status = row
    if status == "locked":
        return True, ("❌ Account permanently locked. Only the System Administrator "
                      "can unlock this account via the Admin Dashboard.")
    lu = _parse_ts(lock_until_raw)
    if lu and _now() < lu:
        remaining = int((lu - _now()).total_seconds())
        mins, secs = divmod(remaining, 60)
        return True, f"⏳ Account temporarily locked. Try again in {mins}m {secs}s."
    if lu and _now() >= lu:
        reset_failed_attempts(email)
    return False, None

# ── OTP resend rate limiting (Section 5.1) ──────────────────────────────────
_OTP_COOLDOWNS = {1: 60, 2: 180, 3: 300}   # 4th+ → 3600
_OTP_MESSAGES = {
    60:  "⏳ Please wait 60 seconds before requesting another OTP.",
    180: "⏳ Please wait 3 minutes before requesting another OTP.",
    300: "⏳ Please wait 5 minutes before requesting another OTP.",
    3600: "⚠️ Too many OTP requests. Please wait 1 hour before trying again.",
}

def can_send_otp(email):
    with get_conn() as conn:
        row = conn.execute("SELECT otp_next_allowed FROM otp_resend_tracker WHERE email=?", (email,)).fetchone()
    if row and time.time() < row[0]:
        remaining = int(row[0] - time.time())
        return False, remaining
    return True, 0

def register_otp_send(email):
    with get_conn() as conn:
        row = conn.execute("SELECT otp_resend_count FROM otp_resend_tracker WHERE email=?", (email,)).fetchone()
        count = (row[0] if row else 0) + 1
        cooldown = _OTP_COOLDOWNS.get(count, 3600)
        next_allowed = time.time() + cooldown
        conn.execute("""INSERT INTO otp_resend_tracker (email, otp_resend_count, otp_next_allowed)
                     VALUES (?, ?, ?)
                     ON CONFLICT(email) DO UPDATE SET
                        otp_resend_count=excluded.otp_resend_count,
                        otp_next_allowed=excluded.otp_next_allowed""",
                     (email, count, next_allowed))
        conn.commit()
    return _OTP_MESSAGES.get(cooldown, _OTP_MESSAGES[3600])

def generate_otp():
    return f"{secrets.randbelow(900000) + 100000}"

def make_otp_token(email, otp):
    payload = {"sub": email, "otp_hash": hash_txt(otp), "type": "password_reset_otp",
               "exp": datetime.datetime.utcnow() + datetime.timedelta(minutes=5)}
    return jwt.encode(payload, JWT_SECRET, algorithm="HS256")

def verify_otp_token(token, input_otp, email):
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=["HS256"])
        if payload.get("sub") != email or payload.get("type") != "password_reset_otp":
            return False, "Security token mismatch."
        if check_txt(input_otp, payload["otp_hash"]):
            return True, "Valid"
        return False, "Invalid 6-digit OTP code."
    except jwt.ExpiredSignatureError:
        return False, "⚠️ This OTP expired after 5 minutes. Please request a new one."
    except Exception:
        return False, "Invalid or corrupted verification token."

def send_otp_email(to_email, otp):
    if not EMAIL_ID or not EMAIL_PASSWORD:
        print(f"[CONSOLE OTP FALLBACK] OTP for {to_email}: {otp}")
        return True, "Email not configured — OTP printed to console (fallback mode)."
    msg = MIMEMultipart("alternative")
    msg["From"] = f"FreightQuote AI <{EMAIL_ID}>"
    msg["To"] = to_email
    msg["Subject"] = "FreightQuote AI — Password Reset OTP"
    msg["Date"] = formatdate(localtime=True)
    msg["Message-ID"] = make_msgid()
    text = f"Your FreightQuote AI OTP is: {otp}\nExpires in 5 minutes."
    html = (f'<div style="font-family:Arial;padding:20px;">'
            f'<h3>FreightQuote AI Verification</h3>'
            f'<p>Your one-time code:</p>'
            f'<div style="font-size:26px;font-weight:bold;letter-spacing:4px;'
            f'background:#ffd803;padding:10px 20px;display:inline-block;border-radius:8px;">{otp}</div>'
            f'<p>Expires in 5 minutes.</p></div>')
    msg.attach(MIMEText(text, "plain"))
    msg.attach(MIMEText(html, "html"))
    try:
        s = smtplib.SMTP("smtp.gmail.com", 587)
        s.starttls()
        s.login(EMAIL_ID, EMAIL_PASSWORD)
        s.sendmail(EMAIL_ID, to_email, msg.as_string())
        s.quit()
        return True, "OTP email sent!"
    except Exception as e:
        return False, f"SMTP Error: {e}"

# ── Main auth portal UI ─────────────────────────────────────────────────────
def render_auth_portal():
    init_auth()
    for k, v in [("token", None), ("otp_token", None), ("otp_email", None),
                 ("otp_verified", False), ("reset_email", None), ("reset_q", None)]:
        if k not in st.session_state: st.session_state[k] = v

    st.markdown(f"""
    <div style="text-align:center;padding:1.5rem 0 1rem;">
        <div style="font-size:44px;margin-bottom:8px;">⚡</div>
        <h1 style="font-size:2rem !important;margin:0;">FreightQuote AI Portal</h1>
        <p style="color:{COLORS['text_muted']};font-size:14px;margin:4px 0 0;">Enterprise Multi-Agent Logistics & Pricing System</p>
    </div>
    """, unsafe_allow_html=True)

    c1, c2, c3 = st.columns([1, 2, 1])
    with c2:
        tab1, tab2, tab3 = st.tabs(["🔐 Sign In", "📝 Register Account", "🔑 Reset Password"])

        # ── TAB 1: LOGIN with progressive lockout ───────────────────────────
        with tab1:
            login_email = st.text_input("Email / Username", key="l_email", placeholder="infosys@ai")
            login_pw = st.text_input("Password", type="password", key="l_pw", placeholder="••••••••")
            if st.button("🚀 Sign In to Portal", key="btn_login"):
                with get_conn() as conn:
                    user = conn.execute(
                        "SELECT username, email, password_hash, role FROM users WHERE email=? OR username=?",
                        (login_email, login_email)).fetchone()
                if not user:
                    st.error("Invalid email/username or password.")
                else:
                    is_locked, lock_msg = check_lock_status(user[1])
                    if is_locked:
                        st.error(lock_msg)
                    elif check_txt(login_pw, user[2]):
                        reset_failed_attempts(user[1])
                        st.session_state["token"] = make_jwt(user[1], user[0], user[3])
                        st.session_state["username"] = user[0]
                        st.session_state["role"] = user[3]
                        st.success(f"Welcome back, {user[0]} [{user[3]}]!")
                        st.rerun()
                    else:
                        fail_msg = register_failed_attempt(user[1])
                        st.error(fail_msg or "Invalid email/username or password.")

        # ── TAB 2: REGISTER with live password strength ─────────────────────
        with tab2:
            r_user = st.text_input("Username", key="r_u")
            r_email = st.text_input("Email Address", key="r_e")
            r_pw = st.text_input("Create Password", type="password", key="r_p")
            render_password_strength_live(r_pw)
            r_role = st.selectbox("Select Enterprise Role",
                                  ["Logistics Manager", "Pricing Analyst", "Carrier Auditor", "Executive"], key="r_role")
            r_q = st.selectbox("Security Question",
                               ["What is your pet name?", "What city were you born in?",
                                "What is your favorite school teacher's name?"], key="r_q")
            r_a = st.text_input("Security Answer", key="r_a")
            if st.button("✨ Create Enterprise Account", key="btn_reg"):
                if not (r_user and r_email and r_pw and r_a):
                    st.warning("Please fill out all fields.")
                else:
                    _, _, allowed, msg = password_strength(r_pw)
                    if not allowed:
                        st.warning(msg)
                    else:
                        try:
                            with get_conn() as conn:
                                conn.execute(
                                    "INSERT INTO users (username, email, password_hash, security_question, "
                                    "security_answer_hash, role) VALUES (?, ?, ?, ?, ?, ?)",
                                    (r_user, r_email, hash_txt(r_pw), r_q, hash_txt(r_a.lower().strip()), r_role))
                                conn.commit()
                            st.success(f"Account registered with role [{r_role}]! Please switch to Sign In tab.")
                        except Exception:
                            st.error("Registration failed: Email or username may already exist.")

        # ── TAB 3: FORGOT PASSWORD — Security Question + Gmail OTP ──────────
        with tab3:
            method = st.radio("Choose recovery method", ["Security Question", "Email OTP"],
                              horizontal=True, key="fp_method")

            if method == "Security Question":
                f_email = st.text_input("Registered Email", key="f_e")
                if st.button("Verify Email & Fetch Question", key="btn_f1"):
                    with get_conn() as conn:
                        u = conn.execute("SELECT security_question FROM users WHERE email=?", (f_email,)).fetchone()
                    if u:
                        st.session_state["reset_email"] = f_email
                        st.session_state["reset_q"] = u[0]
                        st.rerun()
                    else:
                        st.error("Email not found.")

                if st.session_state.get("reset_email"):
                    st.info(f"Security Question: **{st.session_state.get('reset_q')}**")
                    ans_try = st.text_input("Enter Answer", key="f_ans")
                    new_pw = st.text_input("New Password", type="password", key="f_npw")
                    render_password_strength_live(new_pw)
                    if st.button("Confirm Password Reset", key="btn_f2"):
                        _, _, allowed, msg = password_strength(new_pw)
                        if not allowed:
                            st.warning(msg)
                        else:
                            with get_conn() as conn:
                                u_hash = conn.execute(
                                    "SELECT security_answer_hash FROM users WHERE email=?",
                                    (st.session_state["reset_email"],)).fetchone()
                            if u_hash and check_txt(ans_try.lower().strip(), u_hash[0]):
                                with get_conn() as conn:
                                    conn.execute("UPDATE users SET password_hash=? WHERE email=?",
                                                (hash_txt(new_pw), st.session_state["reset_email"]))
                                    conn.commit()
                                st.success("Password reset successfully! Please sign in.")
                                st.session_state["reset_email"] = None
                            else:
                                st.error("Incorrect security answer.")

            else:  # Email OTP route
                if not st.session_state["otp_verified"]:
                    otp_email = st.text_input("Registered Email", key="otp_e",
                                              value=st.session_state.get("otp_email") or "")
                    c_send, c_resend = st.columns(2)
                    with c_send:
                        if st.button("📧 Send OTP", key="btn_send_otp", use_container_width=True):
                            with get_conn() as conn:
                                u = conn.execute("SELECT 1 FROM users WHERE email=?", (otp_email,)).fetchone()
                            if not u:
                                st.error("Email not registered.")
                            else:
                                allowed, remaining = can_send_otp(otp_email)
                                if not allowed:
                                    m, s = divmod(remaining, 60)
                                    st.warning(f"⏳ Please wait {m}m {s}s before requesting another OTP.")
                                else:
                                    otp = generate_otp()
                                    ok, send_msg = send_otp_email(otp_email, otp)
                                    if ok:
                                        st.session_state["otp_token"] = make_otp_token(otp_email, otp)
                                        st.session_state["otp_email"] = otp_email
                                        cooldown_msg = register_otp_send(otp_email)
                                        st.success(f"✅ OTP sent to {otp_email}!")
                                        st.caption(cooldown_msg)
                                    else:
                                        st.error(send_msg)
                    with c_resend:
                        if st.button("🔁 Resend OTP", key="btn_resend_otp", use_container_width=True):
                            if not otp_email:
                                st.warning("Enter your email first.")
                            else:
                                allowed, remaining = can_send_otp(otp_email)
                                if not allowed:
                                    m, s = divmod(remaining, 60)
                                    st.warning(f"⏳ Please wait {m}m {s}s before requesting another OTP.")
                                else:
                                    otp = generate_otp()
                                    ok, send_msg = send_otp_email(otp_email, otp)
                                    if ok:
                                        st.session_state["otp_token"] = make_otp_token(otp_email, otp)
                                        st.session_state["otp_email"] = otp_email
                                        cooldown_msg = register_otp_send(otp_email)
                                        st.success("✅ New OTP sent!")
                                        st.caption(cooldown_msg)
                                    else:
                                        st.error(send_msg)

                    if st.session_state.get("otp_token"):
                        otp_input = st.text_input("Enter 6-digit OTP", max_chars=6, key="otp_input")
                        if st.button("Verify OTP →", key="btn_verify_otp"):
                            ok, msg = verify_otp_token(st.session_state["otp_token"], otp_input,
                                                       st.session_state["otp_email"])
                            if ok:
                                st.session_state["otp_verified"] = True
                                st.success("✅ OTP verified!")
                                st.rerun()
                            else:
                                st.error(msg)
                else:
                    st.info(f"Identity verified for **{st.session_state['otp_email']}**")
                    new_pw2 = st.text_input("New Password", type="password", key="otp_new_pw")
                    render_password_strength_live(new_pw2)
                    if st.button("Update Password", key="btn_otp_update"):
                        _, _, allowed, msg = password_strength(new_pw2)
                        if not allowed:
                            st.warning(msg)
                        else:
                            with get_conn() as conn:
                                conn.execute("UPDATE users SET password_hash=? WHERE email=?",
                                            (hash_txt(new_pw2), st.session_state["otp_email"]))
                                conn.commit()
                            st.success("🎉 Password updated! Please sign in.")
                            st.session_state["otp_verified"] = False
                            st.session_state["otp_token"] = None
                            st.session_state["otp_email"] = None
